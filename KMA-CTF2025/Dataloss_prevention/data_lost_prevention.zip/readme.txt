docker-compose up -d
chmod +x ./init-flag.sh && ./init-flag.sh