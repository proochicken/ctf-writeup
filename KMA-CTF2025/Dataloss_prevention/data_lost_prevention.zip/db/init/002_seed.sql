INSERT INTO users(username, password_hash)
VALUES ('demo', '$2y$10$7z49YH3j3Jr7c8s2G1hQte8xqA1xjvUQKQpJ9f8rPJ5Edbu1X8Hs6');

INSERT INTO cases(title, owner_id) VALUES
('Quarterly Incident Review', 1),
('PCI Audit', 1);
