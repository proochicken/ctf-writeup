#!/bin/sh
set -e

exec apache2-foreground
